Italiano

Passaggi per giocare a Tombolone:

1) -- SCARICARE L'AMBIENTE --

Per poter giocare bisogna scaricare python e la sua relativa libreria. A seconda del sistema 
operativo bisogna seguire questi passaggi.


-LINUX-

2)aprire il terminale e digitare il seguente comando:
-sudo apt-get install python3.8
3)a questo punto autenticarsi inserendo le proprie credenzziali del PC, successivamente bisogna installare la libreria tkinter mediante questo comando:
-sudo apt-get install python3-tk
4)installare anche il comando per poter far uso della pygame per poter avere un'interfaccia audio migliore tramite il comando:
-sudo apt-get install python3-pygame
5)a questo punto autenticarsi inserendo le proprie credenzziali del PC, successivamente
-sudo apt install python3-pip

6)Fatto questo per avviare il gioco vero e proprio non si dovrà fare doppio click sul file 
perchè verrà visualizzato il codice, ma aprire il terminale nella cartella dove si trova il
file e avviare il programma con il comando:
-python3 Tombolone.py


---------------------------------------------------------------------------------------------------------------------------------------------------
English

Steps to play Tombolone:

1) - DOWNLOAD THE ENVIRONMENT -

In order to play you need to download python and its related library. Depending on the system
operational you have to follow these steps.


-LINUX-

2)open the terminal and type the following command:
-sudo apt-get install python3.8
3)at this point, log in by entering your PC credentials, subsequently you need to install the tkinter library using this command:
-sudo apt-get install python3-tk
4)also install the command to be able to make use of the pygame in order to have a better audio interface using the command:
-sudo apt-get install python3-pygame
5)at this point, log in by entering your PC credentials, subsequently
-sudo apt install python3-pip

6)Once this is done, you will not have to double click on the file to start the actual game
because the code will be displayed, but open the terminal in the folder where it is located
file and start the program with the command:
-python3 Tombolone.py
